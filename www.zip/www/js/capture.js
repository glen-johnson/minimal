function doCapture(id,choice) {
	alert("ID = " + id + ". Choice = " + choice);
}